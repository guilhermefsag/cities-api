package com.github.guilhermefsag.citiesapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CitiesApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
